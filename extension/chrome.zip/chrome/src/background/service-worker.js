/**
 * @project    ELY — Exactly Like You
 * @file       extension/chrome/src/background/service-worker.js
 * @brief      MV3 service worker — owns the WebSocket to the ELY backend and
 *             routes commands to/from the active tab's content script.
 *
 * Lifecycle:
 *   - On startup OR when config changes, attempt to connect.
 *   - WebSocket connects to <backendUrl>/ws/browser-extension with JWT
 *     passed via the initial HELLO envelope (cookie-less auth — works
 *     even from a different origin than the ELY web app).
 *   - Reconnect with exponential backoff (1s → 30s) if the socket drops.
 *   - Forward READ_DOM/CLICK/FILL/etc. to the active tab's content
 *     script via chrome.tabs.sendMessage(); pass results back to backend.
 */

import { CMD, EVT, makeEnvelope, makeResult } from "../shared/protocol.js";
import { getConfig, markSeen } from "../shared/storage.js";

// ── State (lives only as long as the service worker is awake) ────────
let ws = null;
let reconnectAttempts = 0;
let reconnectTimer = null;
let lastError = null;
// When set, we stop trying to reconnect automatically — only a manual
// "Reconnect" click from the popup or a config change wakes us up.
let suspended = false;
// Re-entrancy guard: prevents two concurrent connect() calls from
// racing each other when storage changes AND the popup explicitly
// sends "ely:reconnect" at almost the same time.
let connecting = false;

const MAX_BACKOFF_MS = 30_000;
const MIN_BACKOFF_MS = 1_000;
// Heartbeat keeps the MV3 service worker alive (Chrome shuts it down
// after ~30s of network inactivity) AND keeps the WebSocket chair
// behind nginx/Cloudflare idle timeouts.
const HEARTBEAT_MS = 20_000;
let heartbeatTimer = null;

// WebSocket close codes that mean "don't bother retrying — the user has
// to fix something". 4001 = invalid token, 4029 = rate-limited, 1008 =
// policy violation (bad handshake).
const FATAL_CLOSE_CODES = new Set([4001, 4029, 1008]);

function log(...args) {
  console.info("[ELY-EXT]", ...args);
}

function broadcastStatus(status, extra = {}) {
  // Popup listens to this to update its UI in real time.
  chrome.runtime.sendMessage({ kind: "ely:status", status, ...extra }).catch(() => {});
}

// ── Connection lifecycle ──────────────────────────────────────────────
async function connect() {
  // Hard guard: prevent concurrent connect() races. Three legitimate
  // entry points exist (onInstalled, onStartup, top-level, storage
  // listener, popup) and they can fire near-simultaneously — without
  // this lock the registry would "replace" a connection with another
  // initiated 50ms earlier, kicking the user into a reconnect loop.
  if (connecting) {
    log("connect() already in progress — ignored");
    return;
  }
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    log("connect() called but socket is already open/connecting — ignored");
    return;
  }
  if (suspended) {
    log("connect() called while suspended — ignoring");
    return;
  }
  connecting = true;
  const { backendUrl, jwt } = await getConfig();
  if (!backendUrl || !jwt) {
    lastError = "missing_config";
    suspended = true; // no point in retrying without config
    connecting = false;
    broadcastStatus("disconnected", { reason: "missing_config" });
    return;
  }

  // Convert https → wss, http → ws.
  const wsUrl = backendUrl.replace(/^https?/, (m) => (m === "https" ? "wss" : "ws"))
                          + "/ws/browser-extension";
  log("Connecting to", wsUrl);
  broadcastStatus("connecting");

  try {
    ws = new WebSocket(wsUrl);
  } catch (e) {
    lastError = String(e);
    connecting = false;
    scheduleReconnect();
    return;
  }

  ws.onopen = async () => {
    log("WebSocket open");
    connecting = false;
    reconnectAttempts = 0;
    // Send HELLO with JWT immediately — backend rejects/closes if invalid.
    const tab = await getActiveTab();
    const hello = makeEnvelope(EVT.HELLO, {
      jwt,
      extension_version: chrome.runtime.getManifest().version,
      user_agent: navigator.userAgent,
      initial_tab: tab ? { id: tab.id, url: tab.url, title: tab.title } : null,
    });
    ws.send(JSON.stringify(hello));
    await markSeen();
    broadcastStatus("connected");
    startHeartbeat();
  };

  ws.onmessage = async (evt) => {
    let env;
    try { env = JSON.parse(evt.data); }
    catch (e) { log("Bad JSON from backend:", e); return; }

    if (env.type === "ping") {
      ws.send(JSON.stringify(makeEnvelope(EVT.PONG, {}, env.id)));
      return;
    }
    if (env.type === "error") {
      log("Backend error:", env.payload);
      lastError = env.payload?.message || "backend_error";
      return;
    }

    // Dispatch a command to the active tab's content script.
    await handleCommand(env);
  };

  ws.onclose = (e) => {
    log("WebSocket closed", e.code, e.reason);
    stopHeartbeat();
    ws = null;
    connecting = false;
    const reason = e.reason || `code_${e.code}`;
    broadcastStatus("disconnected", { reason });
    // On fatal codes, freeze the loop and wait for the user to act.
    if (FATAL_CLOSE_CODES.has(e.code)) {
      suspended = true;
      lastError = reason;
      log("Suspending auto-reconnect — fix the config or click Reconnect.");
      return;
    }
    scheduleReconnect();
  };

  ws.onerror = (e) => {
    log("WebSocket error", e);
    lastError = "ws_error";
    connecting = false;
  };
}

function startHeartbeat() {
  stopHeartbeat();
  heartbeatTimer = setInterval(() => {
    if (ws?.readyState !== WebSocket.OPEN) return;
    try { ws.send(JSON.stringify(makeEnvelope("ping"))); }
    catch (e) { log("heartbeat failed:", e); }
  }, HEARTBEAT_MS);
}
function stopHeartbeat() {
  if (heartbeatTimer) { clearInterval(heartbeatTimer); heartbeatTimer = null; }
}

function scheduleReconnect() {
  if (suspended) return;
  if (reconnectTimer) clearTimeout(reconnectTimer);
  const delay = Math.min(
    MAX_BACKOFF_MS,
    MIN_BACKOFF_MS * Math.pow(2, reconnectAttempts),
  );
  reconnectAttempts++;
  log(`Reconnecting in ${delay}ms (attempt ${reconnectAttempts})`);
  reconnectTimer = setTimeout(() => connect().catch(log), delay);
}

function disconnect() {
  if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
  if (ws) { try { ws.close(); } catch {} ws = null; }
  suspended = true;
  broadcastStatus("disconnected", { reason: "manual" });
}

// Called from popup "Reconnect" button or from storage change.
function manualReconnect() {
  suspended = false;
  reconnectAttempts = 0;
  if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
  if (ws) { try { ws.close(); } catch {} ws = null; }
  connect().catch(log);
}

// ── Tab helpers ───────────────────────────────────────────────────────
async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return tab || null;
}

// ── Command dispatch (backend → content script) ──────────────────────
async function handleCommand(env) {
  const tab = await getActiveTab();
  if (!tab) {
    ws?.send(JSON.stringify(makeResult(env.id, false, null, "no_active_tab")));
    return;
  }

  // Tabs on chrome:// or extension pages can't be scripted.
  if (!/^https?:/i.test(tab.url || "")) {
    ws?.send(JSON.stringify(makeResult(env.id, false, null, "protected_url")));
    return;
  }

  // Special-case: GET_URL handled entirely by the service worker
  // (no need to roundtrip to content script).
  if (env.type === CMD.GET_URL) {
    ws?.send(JSON.stringify(makeResult(env.id, true, {
      tab_id: tab.id, url: tab.url, title: tab.title,
    })));
    return;
  }

  // SCREENSHOT also lives in the SW (chrome.tabs.captureVisibleTab).
  if (env.type === CMD.SCREENSHOT) {
    try {
      const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
      ws?.send(JSON.stringify(makeResult(env.id, true, { data_url: dataUrl })));
    } catch (e) {
      ws?.send(JSON.stringify(makeResult(env.id, false, null, String(e))));
    }
    return;
  }

  // Everything else: forward to the content script.
  try {
    const response = await chrome.tabs.sendMessage(tab.id, {
      kind: "ely:cmd",
      envelope: env,
    });
    ws?.send(JSON.stringify(makeResult(env.id, true, response)));
  } catch (e) {
    ws?.send(JSON.stringify(makeResult(env.id, false, null, String(e))));
  }
}

// ── Tab events → backend ─────────────────────────────────────────────
chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (tab && ws?.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(makeEnvelope(EVT.TAB_CHANGED, {
      tab_id: tab.id, url: tab.url, title: tab.title,
    })));
  }
});

chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === "complete" && ws?.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(makeEnvelope(EVT.PAGE_NAVIGATED, {
      tab_id: tabId, url: tab.url, title: tab.title,
    })));
  }
});

// ── Messages from popup / options page / content scripts ─────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.kind === "ely:reconnect") {
    manualReconnect();
    sendResponse({ ok: true });
    return false;
  }
  if (msg?.kind === "ely:disconnect") {
    disconnect();
    sendResponse({ ok: true });
    return false;
  }
  if (msg?.kind === "ely:get-status") {
    sendResponse({
      connected: ws?.readyState === WebSocket.OPEN,
      lastError,
      readyState: ws?.readyState ?? -1,
    });
    return false;
  }
  if (msg?.kind === "ely:hitl-decision") {
    // Forward the user's HITL choice back to the backend.
    if (ws?.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(makeEnvelope(EVT.HITL_DECISION, msg.payload)));
    }
    sendResponse({ ok: true });
    return false;
  }
  return false;
});

// ── Storage changes (config update via Options page) ─────────────────
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.ely_backend_url || changes.ely_jwt) {
    log("Config changed, reconnecting…");
    manualReconnect();
  }
});

// ── Startup ──────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  log("Installed", chrome.runtime.getManifest().version);
  connect().catch(log);
});
chrome.runtime.onStartup.addListener(() => {
  connect().catch(log);
});
// Attempt connection immediately when the SW spins up (e.g. after sleep).
connect().catch(log);
