/**
 * @project    ELY — Exactly Like You
 * @file       extension/chrome/src/shared/protocol.js
 * @brief      Typed message protocol for ELY browser extension <-> backend
 *
 * Protocol overview:
 *   - The extension connects to the backend over wss:// on the user's
 *     configured ELY instance (e.g. ely.catalogmaker.fr).
 *   - All messages are JSON envelopes: { id, type, payload, ts }.
 *   - The backend issues commands (READ_DOM, CLICK, FILL, SCREENSHOT…).
 *   - The extension responds with the same `id` and a result/error.
 *   - The extension also pushes events (TAB_CHANGED, PAGE_NAVIGATED…).
 *   - Every destructive action goes through HITL: the extension renders
 *     an in-page overlay and waits for the user's explicit approval
 *     before executing. The user's choice is sent back to the backend.
 *
 * Versioning:
 *   - PROTOCOL_VERSION is bumped on every breaking change to the
 *     message shape. Backend rejects extensions on mismatched majors.
 */

export const PROTOCOL_VERSION = "0.1.0";

// ── Command types (backend → extension) ──────────────────────────────
export const CMD = Object.freeze({
  PING: "ping",                  // backend keepalive
  READ_DOM: "read_dom",          // serialize the active tab DOM (or a selector)
  READ_TEXT: "read_text",        // textContent of active tab body or selector
  GET_URL: "get_url",            // current tab URL + title
  SCREENSHOT: "screenshot",      // visible viewport as base64 PNG
  CLICK: "click",                // click(selector) — DESTRUCTIVE → HITL
  FILL: "fill",                  // fill(selector, value) — DESTRUCTIVE → HITL
  NAVIGATE: "navigate",          // load URL in active tab — DESTRUCTIVE → HITL
  WAIT_FOR: "wait_for",          // wait for selector to appear (read-only)
});

// ── Event types (extension → backend) ────────────────────────────────
export const EVT = Object.freeze({
  HELLO: "hello",                // sent on connect with extension info + auth
  TAB_CHANGED: "tab_changed",    // active tab id/URL changed
  PAGE_NAVIGATED: "page_navigated", // a tab finished loading a new URL
  HITL_DECISION: "hitl_decision", // user accepted/refused a destructive action
  PONG: "pong",
});

// Read-only commands don't require HITL approval.
const READ_ONLY_CMDS = new Set([
  CMD.PING, CMD.READ_DOM, CMD.READ_TEXT, CMD.GET_URL,
  CMD.SCREENSHOT, CMD.WAIT_FOR,
]);

export function isDestructive(commandType) {
  return !READ_ONLY_CMDS.has(commandType);
}

// ── Envelope helpers ─────────────────────────────────────────────────
let _nextId = 1;
export function makeEnvelope(type, payload = {}, id = null) {
  return {
    v: PROTOCOL_VERSION,
    id: id ?? `ext-${Date.now()}-${_nextId++}`,
    type,
    payload,
    ts: Date.now(),
  };
}

export function makeResult(requestId, ok, data = null, error = null) {
  return {
    v: PROTOCOL_VERSION,
    id: requestId,
    type: "result",
    payload: { ok, data, error },
    ts: Date.now(),
  };
}
